package org.xiaoxingqi.gmdoc.impl.global;

public interface AtlistCallback {
}
