package org.xiaoxingqi.gmdoc.impl.game;

import org.xiaoxingqi.gmdoc.entity.game.GameListData;

public interface GameListCallBack {
    void getGameList(GameListData data);

}
