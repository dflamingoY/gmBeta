package org.xiaoxingqi.gmdoc.listener;

public interface OnGameTabClickListener {

    void onplatClick(String name, int position);

    void versionClick(int id);

    void sellClick(int id);

    void releasClick(int id);

}
