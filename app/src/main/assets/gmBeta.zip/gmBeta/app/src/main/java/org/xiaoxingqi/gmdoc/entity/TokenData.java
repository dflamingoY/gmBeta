package org.xiaoxingqi.gmdoc.entity;

/**
 * Created by yzm on 2017/11/2.{"_token":"2lQ0sMydp6kOujGJ6rbgvsO6WRi68nHgIg2QJ4BX"}
 */

public class TokenData extends BaseRespData {

    private String _token;

    public String get_token() {
        return _token;
    }

    public void set_token(String _token) {
        this._token = _token;
    }

    @Override
    public String toString() {
        return _token;
    }
}
