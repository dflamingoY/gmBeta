package org.xiaoxingqi.gmdoc.impl.home

import org.xiaoxingqi.gmdoc.entity.GroupData

interface LifeFragCallback {

    fun getGroupData(data: GroupData)
}