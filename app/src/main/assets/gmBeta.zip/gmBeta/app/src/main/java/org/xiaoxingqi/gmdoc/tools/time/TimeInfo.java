package org.xiaoxingqi.gmdoc.tools.time;

/**
 * Created by yzm on 2017/12/5.
 */

public class TimeInfo {
    private long startTime;
    private long endTime;

    public TimeInfo() {
    }

    public long getStartTime() {
        return this.startTime;
    }

    public void setStartTime(long var1) {
        this.startTime = var1;
    }

    public long getEndTime() {
        return this.endTime;
    }

    public void setEndTime(long var1) {
        this.endTime = var1;
    }
}
