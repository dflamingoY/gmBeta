package org.xiaoxingqi.gmdoc.eventbus

import org.xiaoxingqi.gmdoc.entity.msg.BaseMsgDetailsBean

class MsgUpdateEvent(var data: BaseMsgDetailsBean) {

}