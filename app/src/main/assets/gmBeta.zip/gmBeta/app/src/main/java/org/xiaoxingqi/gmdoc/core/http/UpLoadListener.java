package org.xiaoxingqi.gmdoc.core.http;

/**
 * Created by yzm on 2017/11/17.
 */

public interface UpLoadListener {

    void upSuccess(String endTag);

    void fail();


}
