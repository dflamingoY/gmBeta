package org.xiaoxingqi.gmdoc.impl;

/**
 *
 */
public interface BaseInterceptor {

    void onError(Object obj);

}
