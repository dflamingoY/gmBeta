package org.xiaoxingqi.gmdoc.impl.login;

import org.xiaoxingqi.gmdoc.entity.login.LoginUserData;

public interface LoginCallBack {

    void loginCall(LoginUserData data);
}
