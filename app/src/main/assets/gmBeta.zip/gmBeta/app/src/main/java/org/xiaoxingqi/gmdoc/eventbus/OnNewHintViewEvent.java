package org.xiaoxingqi.gmdoc.eventbus;

public class OnNewHintViewEvent {
}
