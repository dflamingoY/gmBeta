package org.xiaoxingqi.gmdoc.eventbus

class SocketOffline {
}