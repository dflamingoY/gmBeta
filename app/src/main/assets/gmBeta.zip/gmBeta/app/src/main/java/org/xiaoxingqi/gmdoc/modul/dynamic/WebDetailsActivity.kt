package org.xiaoxingqi.gmdoc.modul.dynamic

import android.support.v7.widget.LinearLayoutManager
import android.view.LayoutInflater
import android.view.View
import kotlinx.android.synthetic.main.activity_recycler_details.*
import org.xiaoxingqi.gmdoc.R
import org.xiaoxingqi.gmdoc.core.BaseActivity
import org.xiaoxingqi.gmdoc.core.adapter.BaseAdapterHelper
import org.xiaoxingqi.gmdoc.core.adapter.QuickAdapter
import org.xiaoxingqi.gmdoc.entity.BowenDetailsData
import org.xiaoxingqi.gmdoc.entity.CommentData
import org.xiaoxingqi.gmdoc.impl.global.WebDetailsCallBack
import org.xiaoxingqi.gmdoc.presenter.global.WebPresenter

/**
 * 文章详情
 */
class WebDetailsActivity : BaseActivity<WebPresenter>() {
    private lateinit var adapter: QuickAdapter<CommentData.CommentDataBean>
    private lateinit var headView: View
    private val mData by lazy { ArrayList<CommentData.CommentDataBean>() }
    private lateinit var id: String


    override fun createPresent(): WebPresenter {
        return WebPresenter(this, object : WebDetailsCallBack() {
            override fun setData(data: CommentData) {

            }

            override fun webDetails(data: BowenDetailsData) {//查看博文的详情




            }
        })
    }

    override fun setContent() {
        setContent(R.layout.activity_recycler_details)
    }

    override fun initView() {
        recyclerView.layoutManager = LinearLayoutManager(this)
        headView = LayoutInflater.from(this).inflate(R.layout.head_web_details, recyclerView, false)
        initActionBar(toolbar)
    }

    override fun initData() {
        id = intent.getStringExtra("id")
        adapter = object : QuickAdapter<CommentData.CommentDataBean>(this, R.layout.layout_item_comment_list_details, mData, headView) {
            override fun convert(helper: BaseAdapterHelper?, item: CommentData.CommentDataBean?) {

            }
        }
        recyclerView.adapter = adapter
        persent?.getDetails(id)
        persent?.getComment(id, 0)
    }

    override fun initEvent() {

    }
}