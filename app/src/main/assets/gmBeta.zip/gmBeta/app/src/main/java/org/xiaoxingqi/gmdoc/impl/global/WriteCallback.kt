package org.xiaoxingqi.gmdoc.impl.global

import org.xiaoxingqi.gmdoc.entity.BaseRespData

open class WriteCallback {

    open fun push(data: BaseRespData) {

    }
}