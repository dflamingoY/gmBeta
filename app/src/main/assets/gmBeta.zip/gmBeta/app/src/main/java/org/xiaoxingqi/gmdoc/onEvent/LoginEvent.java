package org.xiaoxingqi.gmdoc.onEvent;

public class LoginEvent {

}
