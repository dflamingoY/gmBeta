package org.xiaoxingqi.gmdoc.impl.game;

import org.xiaoxingqi.gmdoc.entity.game.GameImageData;
import org.xiaoxingqi.gmdoc.entity.game.GameVideoImgData;

public class GameVideoCallback {

    public void getVideoList(GameVideoImgData data) {
    }

    public void getImgList(GameImageData data) {
    }
}
