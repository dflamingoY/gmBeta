package org.xiaoxingqi.gmdoc.impl.home

import org.xiaoxingqi.gmdoc.entity.user.UserInfoData

abstract class UserInfoCallBack {

    abstract fun userInfo(info: UserInfoData?)








}