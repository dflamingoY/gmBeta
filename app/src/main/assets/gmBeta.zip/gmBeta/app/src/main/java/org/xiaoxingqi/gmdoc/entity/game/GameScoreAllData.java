package org.xiaoxingqi.gmdoc.entity.game;


import java.util.List;

/**
 * Created by yzm on 2017/11/9.
 */

public class GameScoreAllData {

    /**
     * game_name : 塞尔达传说 荒野之息
     * list : []
     * short : [{"name":"戏子","uid":40,"img":"http://image.gmdoc.com/AVATAR_150406848502349.jpg?imageView2/1/w/80","like_game":"实况足球 塞尔达传说 荒野之息 D O T A","self_title":"短评","type":1,"is_ori":1,"cover":null,"content":"这是个爬山跳伞的游戏，开地图，找神庙:joy::joy:不玩剧情，拿到滑翔板之后就可以去探险了:kissing_heart::kissing_heart:","created_at":"2017-07-06 17:59:05","good":"自由度很高","bad":"","score":10,"like_num":3,"comment_num":1,"aid":1114,"no_comment":0,"no_forward":0,"summary":"","ranking":2,"is_help":null,"is_like":null,"pay_status":0,"is_col":0,"is_sub":0},{"name":"上班想要床上压鬼","uid":39,"img":"http://image.gmdoc.com/FtVHEj6D5-70gTkvzRUvCRQBWl_C","like_game":"黑暗之魂3 薪火渐逝 TO THE MOON UNDERTALE 传说之下","self_title":"v就坚持坚持坚持奖学金相机","type":1,"is_ori":1,"cover":null,"content":"v就坚持坚持坚持奖学金相机","created_at":"2017-08-25 20:31:13","good":"附近的就放假","bad":null,"score":5,"like_num":2,"comment_num":1,"aid":2504,"no_comment":0,"no_forward":0,"summary":"","ranking":11,"is_help":null,"is_like":null,"pay_status":0,"is_col":0,"is_sub":0},{"name":"一朵小白云","uid":37,"img":"http://image.gmdoc.com/AVATAR_150761150279743.png?imageView2/1/w/140/q/50","like_game":"Pokemon 樱花大战 异度之刃","self_title":"将计就计加","type":1,"is_ori":1,"cover":null,"content":"将计就计加","created_at":"2017-08-25 23:01:08","good":null,"bad":null,"score":10,"like_num":2,"comment_num":0,"aid":2549,"no_comment":0,"no_forward":0,"summary":"","ranking":12,"is_help":null,"is_like":null,"pay_status":0,"is_col":0,"is_sub":0},{"name":"小林克","uid":34,"img":"http://image.gmdoc.com/FhUrtsI7aRY--U2nmxurElP-OgLl","like_game":"塞尔达传说 喷射战士2 最终生还者","self_title":"短评","type":1,"is_ori":1,"cover":null,"content":"cdscwv ","created_at":"2017-08-18 20:14:14","good":"","bad":"","score":10,"like_num":1,"comment_num":1,"aid":2385,"no_comment":0,"no_forward":0,"summary":"","ranking":5,"is_help":null,"is_like":null,"pay_status":0,"is_col":0,"is_sub":0},{"name":"小林克","uid":34,"img":"http://image.gmdoc.com/FhUrtsI7aRY--U2nmxurElP-OgLl","like_game":"塞尔达传说 喷射战士2 最终生还者","self_title":"短评","type":1,"is_ori":1,"cover":null,"content":"让哥哥日个人个而个让哥哥日该扔的vfddbfbbfdbdfbebeberbrergeger热个人个热个人哥哥人格个人各人格个人各个个人个人供热个个人个人个人个人风格的风格人各人格个人个:teasing:","created_at":"2017-08-25 23:25:47","good":"个个二个如果","bad":"个热歌如果","score":0,"like_num":1,"comment_num":0,"aid":2560,"no_comment":0,"no_forward":0,"summary":"","ranking":6,"is_help":null,"is_like":null,"pay_status":0,"is_col":0,"is_sub":0},{"name":"小林克","uid":34,"img":"http://image.gmdoc.com/FhUrtsI7aRY--U2nmxurElP-OgLl","like_game":"塞尔达传说 喷射战士2 最终生还者","self_title":"是好多好多好多顶焦度计你的电脑嫩","type":1,"is_ori":1,"cover":null,"content":"是好多好多好多顶焦度计你的电脑嫩","created_at":"2017-08-25 23:38:26","good":"所见即所得好多话","bad":null,"score":8,"like_num":1,"comment_num":0,"aid":2566,"no_comment":0,"no_forward":0,"summary":"","ranking":13,"is_help":null,"is_like":null,"pay_status":0,"is_col":0,"is_sub":0},{"name":"拉面新闻","uid":59,"img":"http://image.gmdoc.com/AVATAR_150659406087791.jpg?imageView2/1/w/140/q/50","like_game":"火影 樱花大战 黑魂","self_title":"短评","type":1,"is_ori":1,"cover":null,"content":"绯闻绯闻范[剧透:文芳为范围分为非个人核对和如何让对方:happy::teasing::proud:]vsdvsdvdsv:teasing::proud::mad::shock::mua::regret::sad:","created_at":"2017-08-31 18:56:18","good":"好玩","bad":"","score":7,"like_num":1,"comment_num":0,"aid":2604,"no_comment":0,"no_forward":0,"summary":"","ranking":4,"is_help":null,"is_like":null,"pay_status":0,"is_col":0,"is_sub":0},{"name":"小林克","uid":34,"img":"http://image.gmdoc.com/FhUrtsI7aRY--U2nmxurElP-OgLl","like_game":"塞尔达传说 喷射战士2 最终生还者","self_title":"短评","type":1,"is_ori":1,"cover":null,"content":"虽然我觉得塞尔达剧情有点单薄，但是瑕不掩瑜。喜欢在宏达的世界中自己溜达的感觉，配合着神殿解谜玩的不亦乐乎，年度游戏提前锁定。","created_at":"2017-07-05 13:52:39","good":"世界大","bad":"剧情稍显单薄，最终boss偏弱","score":10,"like_num":0,"comment_num":0,"aid":1060,"no_comment":0,"no_forward":0,"summary":"","ranking":1,"is_help":null,"is_like":null,"pay_status":0,"is_col":0,"is_sub":0},{"name":"戏子","uid":40,"img":"http://image.gmdoc.com/AVATAR_150406848502349.jpg?imageView2/1/w/80","like_game":"实况足球 塞尔达传说 荒野之息 D O T A","self_title":"短评","type":1,"is_ori":1,"cover":null,"content":"嗯嗯","created_at":"2017-08-15 20:59:36","good":"呵呵","bad":"嘻嘻","score":10,"like_num":0,"comment_num":0,"aid":2298,"no_comment":0,"no_forward":0,"summary":"","ranking":3,"is_help":null,"is_like":null,"pay_status":0,"is_col":0,"is_sub":0},{"name":"小林克","uid":34,"img":"http://image.gmdoc.com/FhUrtsI7aRY--U2nmxurElP-OgLl","like_game":"塞尔达传说 喷射战士2 最终生还者","self_title":"啊；死了的卡；啊啦打开；啊路上看电视啊；路上看到；啊是看到；阿斯顿；啊开始的空间啊是的卡就会死的快啊是空间的机会啊卡建设的啊卡建设的空间啊的空间啊还是的😊😊😩😩😔❤️❤️❤️😉😉😉","type":1,"is_ori":1,"cover":null,"content":"啊；死了的卡；啊啦打开；啊路上看电视啊；路上看到；啊是看到；阿斯顿；啊开始的空间啊是的卡就会死的快啊是空间的机会啊卡建设的啊卡建设的空间啊的空间啊还是的😊😊😩😩😔❤️❤️❤️😉😉😉","created_at":"2017-08-25 20:10:57","good":"Zddasd ","bad":"asdasdasd","score":10,"like_num":0,"comment_num":0,"aid":2495,"no_comment":0,"no_forward":0,"summary":"","ranking":8,"is_help":null,"is_like":null,"pay_status":0,"is_col":0,"is_sub":0},{"name":"上班想要床上压鬼","uid":39,"img":"http://image.gmdoc.com/FtVHEj6D5-70gTkvzRUvCRQBWl_C","like_game":"黑暗之魂3 薪火渐逝 TO THE MOON UNDERTALE 传说之下","self_title":"烦恼现金超级超级","type":1,"is_ori":1,"cover":null,"content":"烦恼现金超级超级","created_at":"2017-08-25 20:25:50","good":"好的好的好的","bad":"谢谢大兄弟","score":10,"like_num":0,"comment_num":0,"aid":2501,"no_comment":0,"no_forward":0,"summary":"","ranking":9,"is_help":null,"is_like":null,"pay_status":0,"is_col":0,"is_sub":0},{"name":"上班想要床上压鬼","uid":39,"img":"http://image.gmdoc.com/FtVHEj6D5-70gTkvzRUvCRQBWl_C","like_game":"黑暗之魂3 薪火渐逝 TO THE MOON UNDERTALE 传说之下","self_title":"嘻嘻嘻吃醋","type":1,"is_ori":1,"cover":null,"content":"嘻嘻嘻吃醋","created_at":"2017-08-25 20:26:08","good":null,"bad":"vvvv","score":0,"like_num":0,"comment_num":0,"aid":2502,"no_comment":0,"no_forward":0,"summary":"","ranking":10,"is_help":null,"is_like":null,"pay_status":0,"is_col":0,"is_sub":0},{"name":"游戏档案","uid":80,"img":"/images/avatar_default.png","like_game":"1 2 3","self_title":"短评","type":1,"is_ori":1,"cover":null,"content":"不可能有缺点","created_at":"2017-09-29 11:24:01","good":"完美的游戏","bad":"","score":10,"like_num":0,"comment_num":0,"aid":2800,"no_comment":0,"no_forward":0,"summary":"","ranking":15,"is_help":null,"is_like":null,"pay_status":0,"is_col":0,"is_sub":0}]
     * short_total : 13
     * long : [{"name":"千年伯爵","uid":43,"img":"/images/defaults/140x140.png","like_game":"塞尔达荒野之息 暗黑破坏神2 血源诅咒","self_title":"没玩过荒野之息=2017年没有玩过游戏","type":2,"is_ori":1,"cover":null,"content":"<p>游戏发售之后，很多人说：没有中文版，绝对不玩。<\/p>\n<p>且不说这种观点是否包含\u201c不喜欢任天堂\u201d的情绪，《荒野之息》中能够主导主线和支线剧情的英语文本，也就是大学英语4级的水准罢了。<\/p>\n<p>《荒野之息》配得上任何赞誉，我想，它也配得上让你查十几个英文单词的那点额外精力。<\/p>\n<p>这个游戏已注定名留青史。<\/p>\n<p>如果说未来的游戏需要做到的是做到证明1+1=2这样的程度，是虚拟现实，是全息投影，是《刀剑神域》中的黑科技头盔，那么荒野之息至少在目前这个时间，在开放世界这个领域里，以自己的方式给出了1＋2=3的伟大证明。<\/p>\n<p>如果把思考和表达压缩，只允许对一款游戏作出第一反应的判断，对于《神海》我会说画面华丽，对于《GTA5》我会说风格写实，对于《巫师3》我会说剧情宏大，对于魂系列我会说难度可怖，对于暴雪游戏我会说世界观非常赞，对于《这是我的战争》我会说深刻，对于《求生之路》和《虐杀原形》我会说酣畅淋漓，对于《辐射3》我会说阴暗的恶趣味，对于《天际》我会说龙的名字很帅气......<\/p>\n<p>对于《荒野之息》，好像没什么能概括的。<\/p>\n<p>就是\u201c好玩\u201d。<\/p>","created_at":"2017-07-05 18:42:35","good":"重新定义开放世界","bad":"偶尔掉帧","score":10,"like_num":2,"comment_num":0,"aid":1072,"no_comment":0,"no_forward":0,"summary":"游戏发售之后，很多人说：没有中文版，绝对不玩。\n且不说这种观点是否包含\u201c不喜欢任天堂\u201d的情绪，《荒野之息》中能够主导主线和支线剧情的英语文本，也就是大学英语4级的水准罢了。\n《荒野之息》配得上任何赞誉，我想，它也配得上让你查十几个英文单词的那点额外精力。\n","ranking":7,"is_help":null,"is_like":null,"pay_status":0,"is_col":0,"is_sub":0},{"name":"小林克","uid":34,"img":"http://image.gmdoc.com/FhUrtsI7aRY--U2nmxurElP-OgLl","like_game":"塞尔达传说 喷射战士2 最终生还者","self_title":"就是继续继续继续基督教你","type":2,"is_ori":1,"cover":"http://cdn.gmdoc.com/Fg1-AFH3tfU4dgUGxqwOaCTci9RY","content":"你滴滴滴滴滴放假放假才能对那些女生就是喜欢喜欢喜欢的好好的会让男人粉嫩放放风\n<br />\n<img src=\"http://cdn.gmdoc.com/FpTTRCrEnPRlstQBdu4HqbRkWWge\" alt=\"[图片]\">\n<div>\n    <br />\n<\/div>","created_at":"2017-08-25 23:48:28","good":"顶焦度计放假放假","bad":"滴滴滴滴滴","score":10,"like_num":2,"comment_num":0,"aid":2570,"no_comment":0,"no_forward":0,"summary":"你滴滴滴滴滴放假放假才能对那些女生就是喜欢喜欢喜欢的好好的会让男人粉嫩放放风\n\n\n\n    \n","ranking":14,"is_help":null,"is_like":null,"pay_status":0,"is_col":0,"is_sub":0},{"name":"戏子","uid":40,"img":"http://image.gmdoc.com/AVATAR_150406848502349.jpg?imageView2/1/w/80","like_game":"实况足球 塞尔达传说 荒野之息 D O T A","self_title":"12","type":2,"is_ori":1,"cover":null,"content":"<p>3<\/p>","created_at":"2017-10-10 12:24:16","good":null,"bad":null,"score":10,"like_num":0,"comment_num":0,"aid":2316,"no_comment":0,"no_forward":0,"summary":"3","ranking":16,"is_help":null,"is_like":null,"pay_status":0,"is_col":0,"is_sub":0}]
     * long_total : 3
     * state : 200
     */

    private String game_name;
    private int short_list_total;
    private int long_list_total;
    private int state;
    private List<BaseScoreBean> list;
    private List<BaseScoreBean> short_list;
    private List<BaseScoreBean> long_list;
    private String total;

    public String getTotal() {
        return total;
    }

    public void setTotal(String total) {
        this.total = total;
    }

    public String getGame_name() {
        return game_name;
    }

    public void setGame_name(String game_name) {
        this.game_name = game_name;
    }

    public int getShort_list_total() {
        return short_list_total;
    }

    public void setShort_list_total(int short_list_total) {
        this.short_list_total = short_list_total;
    }

    public int getLong_list_total() {
        return long_list_total;
    }

    public void setLong_list_total(int long_list_total) {
        this.long_list_total = long_list_total;
    }

    public int getState() {
        return state;
    }

    public void setState(int state) {
        this.state = state;
    }

    public List<BaseScoreBean> getList() {
        return list;
    }

    public void setList(List<BaseScoreBean> list) {
        this.list = list;
    }

    public List<BaseScoreBean> getShort_list() {
        return short_list;
    }

    public void setShort_list(List<BaseScoreBean> short_list) {
        this.short_list = short_list;
    }

    public List<BaseScoreBean> getLong_list() {
        return long_list;
    }

    public void setLong_list(List<BaseScoreBean> long_list) {
        this.long_list = long_list;
    }
}
