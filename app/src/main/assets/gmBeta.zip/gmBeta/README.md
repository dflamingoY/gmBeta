# gmBeta
一个游戏评分Demo
# 该项目主要是作为功能点展示
1.TextView中展示emoji表情,gif表情,文本剧透等基础的社区属性

2.文本编辑使用webView作为文本编辑器, 输出富文本

###项目采用混编(kotlin+java)后期希望能跟进flutter
网络框架采用okhttp+retrofit2 整体还算比较简单,细节较多